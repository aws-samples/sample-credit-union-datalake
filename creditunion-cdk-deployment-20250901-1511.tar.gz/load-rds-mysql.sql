-- Create table for core banking members
CREATE TABLE IF NOT EXISTS core_banking_members (
    member_number VARCHAR(20) PRIMARY KEY,
    ssn VARCHAR(11),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dob DATE,
    address VARCHAR(200),
    city VARCHAR(50),
    state VARCHAR(2),
    zip VARCHAR(10),
    phone VARCHAR(20),
    join_date DATE,
    checking_balance DECIMAL(10,2),
    savings_balance DECIMAL(10,2)
);

-- Clear existing data
DELETE FROM core_banking_members;

-- Sample insert statements (you'll need to run the full CSV load)
INSERT INTO core_banking_members VALUES 
('496032','897-70-1987','DANIELLE','JOHNSON','1958-04-18','18196 ANTHONY FORGE','NEW CAROLYN','WV','74064','886.737.94','2016-04-17',11823.30,21365.73),
('903370','186-61-4715','MICHAEL','COOPER','1957-07-31','781 MILLER HILL','BARBARALAND','WV','06507','+163431316','2016-04-15',5648.80,18107.10);
