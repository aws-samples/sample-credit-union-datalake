# CloudShell Deployment Guide

## Prerequisites
- Admin access to AWS account
- CloudShell access in target region

## Step-by-Step Deployment

### 1. Upload Files to CloudShell
- Create zip: `tar -czf CDK-minimal.tar.gz lib/ bin/ sample-data/ package.json package-lock.json tsconfig.json cdk.json jest.config.js README.md DEPLOYMENT_CHECKLIST.md`
- Upload `CDK-minimal.tar.gz` to CloudShell
- Extract: `tar -xzf CDK-minimal.tar.gz`

### 2. Install Dependencies
```bash
npm install
```

### 3. Bootstrap CDK (First Time Only)
```bash
./node_modules/.bin/cdk bootstrap --region us-west-2
```
*Note: Replace us-west-2 with your target region*

### 4. Deploy Infrastructure Stacks
```bash
# Deploy infrastructure (S3, RDS, VPC, IAM)
./node_modules/.bin/cdk deploy CreditUnionInfrastructureStack --app "node bin/cdk.js" --region us-west-2

# Deploy data catalog (Glue databases, connections)
./node_modules/.bin/cdk deploy CreditUnionDataStack --app "node bin/cdk.js" --region us-west-2

# Deploy ETL jobs (Glue jobs, Step Functions)
./node_modules/.bin/cdk deploy CreditUnionETLStack --app "node bin/cdk.js" --region us-west-2
```

## Important Notes

### Use Direct CDK Path
- **Don't use**: `npx cdk` (doesn't work reliably in CloudShell)
- **Use**: `./node_modules/.bin/cdk` (direct path to local CDK)

### Always Specify App
- **Don't use**: `cdk deploy StackName`
- **Use**: `cdk deploy StackName --app "node bin/cdk.js"`

### Bootstrap Required
- Must run `cdk bootstrap` once per region before first deployment
- Creates CDKToolkit stack with required S3 buckets and IAM roles

## Troubleshooting

### If CDK commands return nothing:
1. Check if bootstrap completed: Look for CDKToolkit stack in CloudFormation
2. Verify admin permissions: `aws sts get-caller-identity`
3. Use direct CDK path: `./node_modules/.bin/cdk`

### If deployment fails:
1. Check CloudFormation events for specific errors
2. Ensure you're in correct region
3. Verify all dependencies installed: `npm ls`

## Expected Timeline
- Bootstrap: 3-5 minutes
- Infrastructure Stack: 8-12 minutes
- Data Stack: 3-5 minutes
- ETL Stack: 5-8 minutes
- **Total**: ~20-30 minutes

## Cleanup
```bash
./node_modules/.bin/cdk destroy --all --app "node bin/cdk.js" --region us-west-2
```
