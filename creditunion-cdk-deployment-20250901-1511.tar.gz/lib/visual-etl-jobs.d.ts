import { Construct } from 'constructs';
export declare class VisualETLJobs extends Construct {
    constructor(scope: Construct, id: string, props: {
        roleArn: string;
        connectionName: string;
        bucketName: string;
    });
}
