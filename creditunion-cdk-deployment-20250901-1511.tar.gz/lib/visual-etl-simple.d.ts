import * as glue from 'aws-cdk-lib/aws-glue';
import { Construct } from 'constructs';
export interface VisualETLProps {
    roleArn: string;
    connectionName: string;
    bucketName: string;
}
export declare class VisualETLJobs extends Construct {
    readonly mysqlVisualJob: glue.CfnJob;
    readonly xmlVisualJob: glue.CfnJob;
    readonly csvVisualJob: glue.CfnJob;
    readonly member360VisualJob: glue.CfnJob;
    constructor(scope: Construct, id: string, props: VisualETLProps);
}
