import * as cdk from 'aws-cdk-lib';
import * as glue from 'aws-cdk-lib/aws-glue';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';
interface CreditUnionDataStackProps extends cdk.StackProps {
    collectBucket: s3.Bucket;
    cleanseBucket: s3.Bucket;
    consumeBucket: s3.Bucket;
    glueRole: iam.Role;
    glueSecurityGroup: ec2.SecurityGroup;
    database: rds.DatabaseInstance;
    databaseSecret: secretsmanager.Secret;
    databaseSecurityGroup: ec2.SecurityGroup;
    vpc: ec2.Vpc;
}
export declare class CreditUnionDataStack extends cdk.Stack {
    readonly glueConnection: glue.CfnConnection;
    readonly cleanseDatabase: glue.CfnDatabase;
    readonly consumeDatabase: glue.CfnDatabase;
    readonly xmlCatalogDatabase: glue.CfnDatabase;
    constructor(scope: Construct, id: string, props: CreditUnionDataStackProps);
}
export {};
