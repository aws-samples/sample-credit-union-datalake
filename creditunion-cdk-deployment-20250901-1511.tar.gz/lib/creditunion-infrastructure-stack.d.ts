import * as cdk from 'aws-cdk-lib';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';
export declare class CreditUnionInfrastructureStack extends cdk.Stack {
    readonly collectBucket: s3.Bucket;
    readonly cleanseBucket: s3.Bucket;
    readonly consumeBucket: s3.Bucket;
    readonly kmsKey: kms.Key;
    readonly glueRole: iam.Role;
    readonly glueSecurityGroup: ec2.SecurityGroup;
    readonly database: rds.DatabaseInstance;
    readonly databaseSecret: secretsmanager.Secret;
    readonly databaseSecurityGroup: ec2.SecurityGroup;
    readonly vpc: ec2.Vpc;
    constructor(scope: Construct, id: string, props?: cdk.StackProps);
}
