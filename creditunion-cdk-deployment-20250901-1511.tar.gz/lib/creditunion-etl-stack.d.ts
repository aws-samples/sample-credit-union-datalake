import * as cdk from 'aws-cdk-lib';
import * as stepfunctions from 'aws-cdk-lib/aws-stepfunctions';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as glue from 'aws-cdk-lib/aws-glue';
import { Construct } from 'constructs';
interface CreditUnionETLStackProps extends cdk.StackProps {
    collectBucket: s3.Bucket;
    cleanseBucket: s3.Bucket;
    consumeBucket: s3.Bucket;
    glueRole: iam.Role;
    glueConnection: glue.CfnConnection;
    cleanseDatabase: glue.CfnDatabase;
    consumeDatabase: glue.CfnDatabase;
    xmlCatalogDatabase: glue.CfnDatabase;
}
export declare class CreditUnionETLStack extends cdk.Stack {
    readonly stepFunction: stepfunctions.StateMachine;
    constructor(scope: Construct, id: string, props: CreditUnionETLStackProps);
}
export {};
