import { Construct } from 'constructs';
export interface VisualETLProps {
    roleArn: string;
    connectionName: string;
    region: string;
}
export declare class VisualETLConstruct extends Construct {
    constructor(scope: Construct, id: string, props: VisualETLProps);
    private createDeploymentProvider;
}
