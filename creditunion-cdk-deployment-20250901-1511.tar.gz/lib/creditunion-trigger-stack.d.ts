import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
interface CreditUnionTriggerStackProps extends cdk.StackProps {
    rdsLambdaFunctionName: string;
    crawlerLambdaFunctionName: string;
    stepFunctionArn: string;
}
export declare class CreditUnionTriggerStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props: CreditUnionTriggerStackProps);
    private createCrawlerWaitFunction;
}
export {};
