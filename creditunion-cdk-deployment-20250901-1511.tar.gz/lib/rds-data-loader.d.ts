import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface RdsDataLoaderProps {
    vpc: ec2.Vpc;
    database: rds.DatabaseInstance;
    databaseSecret: rds.DatabaseSecret;
    collectBucket: s3.Bucket;
}
export declare class RdsDataLoader extends Construct {
    readonly lambda: lambda.Function;
    constructor(scope: Construct, id: string, props: RdsDataLoaderProps);
}
