import * as glue from 'aws-cdk-lib/aws-glue';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
interface CSVETLJobProps {
    glueRole: iam.Role;
    collectBucket: s3.Bucket;
    cleanseBucket: s3.Bucket;
    cleanseDatabase: glue.CfnDatabase;
}
export declare class CSVETLJob extends Construct {
    readonly job: glue.CfnJob;
    constructor(scope: Construct, id: string, props: CSVETLJobProps);
}
export {};
