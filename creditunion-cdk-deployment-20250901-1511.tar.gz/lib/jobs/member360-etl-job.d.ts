import * as glue from 'aws-cdk-lib/aws-glue';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
interface Member360ETLJobProps {
    glueRole: iam.Role;
    consumeBucket: s3.Bucket;
    cleanseDatabase: glue.CfnDatabase;
    consumeDatabase: glue.CfnDatabase;
    xmlCatalogDatabase: glue.CfnDatabase;
}
export declare class Member360ETLJob extends Construct {
    readonly job: glue.CfnJob;
    constructor(scope: Construct, id: string, props: Member360ETLJobProps);
}
export {};
