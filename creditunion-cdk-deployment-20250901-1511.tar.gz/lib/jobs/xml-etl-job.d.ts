import * as glue from 'aws-cdk-lib/aws-glue';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
interface XMLETLJobProps {
    glueRole: iam.Role;
    cleanseBucket: s3.Bucket;
    xmlCatalogDatabase: glue.CfnDatabase;
}
export declare class XMLETLJob extends Construct {
    readonly job: glue.CfnJob;
    constructor(scope: Construct, id: string, props: XMLETLJobProps);
}
export {};
