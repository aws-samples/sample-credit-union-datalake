import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
interface RDSDataLoaderProps {
    vpc: ec2.Vpc;
    collectBucket: s3.Bucket;
    secretArn: string;
    glueSecurityGroup: ec2.SecurityGroup;
}
export declare class RDSDataLoader extends Construct {
    readonly function: lambda.Function;
    constructor(scope: Construct, id: string, props: RDSDataLoaderProps);
}
export {};
