import json
import boto3
import pymysql
import csv
from io import StringIO

def lambda_handler(event, context):
    # Get RDS credentials from Secrets Manager
    secrets_client = boto3.client('secretsmanager')
    secret_response = secrets_client.get_secret_value(
        SecretId='DatabaseSecret86DBB7B3-7PuWCNAOhDnY'
    )
    
    secret = json.loads(secret_response['SecretString'])
    
    # Get CSV data from S3
    s3_client = boto3.client('s3')
    csv_response = s3_client.get_object(
        Bucket='creditunion-546549546983-us-west-2-collect',
        Key='CreditUnionData/core_banking_members.csv'
    )
    
    csv_content = csv_response['Body'].read().decode('utf-8')
    
    # Connect to MySQL
    connection = pymysql.connect(
        host=secret['host'],
        user=secret['username'],
        password=secret['password'],
        database=secret['dbname'],
        port=secret['port']
    )
    
    try:
        with connection.cursor() as cursor:
            # Create table if not exists
            create_table_sql = """
            CREATE TABLE IF NOT EXISTS core_banking_members (
                member_number VARCHAR(20) PRIMARY KEY,
                ssn VARCHAR(11),
                first_name VARCHAR(50),
                last_name VARCHAR(50),
                dob DATE,
                address VARCHAR(200),
                city VARCHAR(50),
                state VARCHAR(2),
                zip VARCHAR(10),
                phone VARCHAR(20),
                join_date DATE,
                checking_balance DECIMAL(10,2),
                savings_balance DECIMAL(10,2)
            )
            """
            cursor.execute(create_table_sql)
            
            # Clear existing data
            cursor.execute("DELETE FROM core_banking_members")
            
            # Parse CSV and insert data
            csv_reader = csv.DictReader(StringIO(csv_content))
            insert_sql = """
            INSERT INTO core_banking_members 
            (member_number, ssn, first_name, last_name, dob, address, city, state, zip, phone, join_date, checking_balance, savings_balance)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            rows_inserted = 0
            for row in csv_reader:
                cursor.execute(insert_sql, (
                    row['member_number'],
                    row['ssn'],
                    row['first_name'],
                    row['last_name'],
                    row['dob'],
                    row['address'],
                    row['city'],
                    row['state'],
                    row['zip'],
                    row['phone'],
                    row['join_date'],
                    float(row['checking_balance']),
                    float(row['savings_balance'])
                ))
                rows_inserted += 1
            
            connection.commit()
            
            return {
                'statusCode': 200,
                'body': json.dumps(f'Successfully loaded {rows_inserted} records into core_banking_members table')
            }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
    finally:
        connection.close()
