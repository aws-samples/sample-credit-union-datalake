#!/usr/bin/env python3
import boto3
import json
import requests
import subprocess
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", "pymysql", "--user"])
import pymysql
import csv

my_ip = requests.get('https://checkip.amazonaws.com').text.strip() + '/32'
print(f"Adding temporary access for IP: {my_ip}")

ec2 = boto3.client('ec2', region_name='us-west-2')
ec2.authorize_security_group_ingress(
    GroupId='sg-00953749bc2402067',
    IpPermissions=[{
        'IpProtocol': 'tcp',
        'FromPort': 3306,
        'ToPort': 3306,
        'IpRanges': [{'CidrIp': my_ip}]
    }]
)

try:
    secrets = boto3.client('secretsmanager', region_name='us-west-2')
    secret = json.loads(secrets.get_secret_value(SecretId='DatabaseSecret86DBB7B3-7PuWCNAOhDnY')['SecretString'])
    
    s3 = boto3.client('s3', region_name='us-west-2')
    s3.download_file('creditunion-546549546983-us-west-2-collect', 'CreditUnionData/CoreBanking_RDS_LoadOnly/core_banking_members.csv', '/tmp/core_banking_members.csv')
    
    conn = pymysql.connect(host=secret['host'], user=secret['username'], password=secret['password'], database=secret['dbname'], port=secret['port'])
    
    with conn.cursor() as cursor:
        cursor.execute("CREATE TABLE IF NOT EXISTS core_banking_members (member_number VARCHAR(20) PRIMARY KEY, ssn VARCHAR(11), first_name VARCHAR(50), last_name VARCHAR(50), dob DATE, address VARCHAR(200), city VARCHAR(50), state VARCHAR(2), zip VARCHAR(10), phone VARCHAR(20), join_date DATE, checking_balance DECIMAL(10,2), savings_balance DECIMAL(10,2))")
        cursor.execute("DELETE FROM core_banking_members")
        
        with open('/tmp/core_banking_members.csv', 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                cursor.execute("INSERT INTO core_banking_members VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", tuple(row.values()))
        
        conn.commit()
        cursor.execute("SELECT COUNT(*) FROM core_banking_members")
        print(f"Loaded {cursor.fetchone()[0]} records")
    
    conn.close()

finally:
    ec2.revoke_security_group_ingress(
        GroupId='sg-00953749bc2402067',
        IpPermissions=[{
            'IpProtocol': 'tcp',
            'FromPort': 3306,
            'ToPort': 3306,
            'IpRanges': [{'CidrIp': my_ip}]
        }]
    )
