#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

/**
 * Process Visual ETL JSON configurations and generate CDK-compatible job definitions
 */
class VisualETLProcessor {
    constructor(configDir, outputDir) {
        this.configDir = configDir;
        this.outputDir = outputDir;
    }

    processConfigurations() {
        const configFiles = fs.readdirSync(this.configDir)
            .filter(file => file.endsWith('-etl-config.json'));

        const jobDefinitions = [];

        configFiles.forEach(file => {
            const configPath = path.join(this.configDir, file);
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            
            if (config.Job && config.Job.CodeGenConfigurationNodes) {
                const jobDef = this.extractJobDefinition(config.Job, file);
                jobDefinitions.push(jobDef);
            }
        });

        this.generateCDKCode(jobDefinitions);
        return jobDefinitions;
    }

    extractJobDefinition(job, filename) {
        return {
            name: job.Name,
            filename: filename.replace('-config.json', ''),
            role: job.Role,
            command: job.Command,
            defaultArguments: job.DefaultArguments,
            connections: job.Connections,
            maxRetries: job.MaxRetries,
            timeout: job.Timeout,
            workerType: job.WorkerType,
            numberOfWorkers: job.NumberOfWorkers,
            glueVersion: job.GlueVersion,
            codeGenConfigurationNodes: job.CodeGenConfigurationNodes,
            executionClass: job.ExecutionClass || 'STANDARD'
        };
    }

    generateCDKCode(jobDefinitions) {
        const cdkCode = `import * as cdk from 'aws-cdk-lib';
import * as glue from 'aws-cdk-lib/aws-glue';
import { Construct } from 'constructs';

export class VisualETLJobs extends Construct {
    constructor(scope: Construct, id: string, props: {
        roleArn: string;
        connectionName: string;
        bucketName: string;
    }) {
        super(scope, id);

${jobDefinitions.map(job => this.generateJobCode(job)).join('\n\n')}
    }
}`;

        fs.writeFileSync(path.join(this.outputDir, 'visual-etl-jobs.ts'), cdkCode);
        console.log('Generated CDK code: visual-etl-jobs.ts');
    }

    generateJobCode(job) {
        return `        // ${job.name}
        new glue.CfnJob(this, '${this.toPascalCase(job.filename)}', {
            name: '${job.name}',
            role: props.roleArn,
            command: {
                name: '${job.command.Name}',
                scriptLocation: '${job.command.ScriptLocation}',
                pythonVersion: '${job.command.PythonVersion}'
            },
            defaultArguments: ${JSON.stringify(job.defaultArguments, null, 16)},
            connections: {
                connections: ['${job.connections?.Connections?.[0] || 'props.connectionName'}']
            },
            maxRetries: ${job.maxRetries},
            timeout: ${job.timeout},
            workerType: '${job.workerType}',
            numberOfWorkers: ${job.numberOfWorkers},
            glueVersion: '${job.glueVersion}',
            executionClass: '${job.executionClass}'
        });`;
    }

    toPascalCase(str) {
        return str.replace(/(^\w|-\w)/g, (match) => 
            match.replace('-', '').toUpperCase()
        );
    }
}

// CLI execution
if (require.main === module) {
    const configDir = process.argv[2] || './configs';
    const outputDir = process.argv[3] || './lib';
    
    const processor = new VisualETLProcessor(configDir, outputDir);
    const jobs = processor.processConfigurations();
    
    console.log(`Processed ${jobs.length} Visual ETL jobs:`);
    jobs.forEach(job => console.log(`  - ${job.name}`));
}

module.exports = { VisualETLProcessor };
