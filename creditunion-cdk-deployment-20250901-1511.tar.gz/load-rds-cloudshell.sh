#!/bin/bash

echo "Loading core banking data into RDS..."

# Get RDS credentials
SECRET_JSON=$(aws secretsmanager get-secret-value --secret-id "DatabaseSecret86DBB7B3-7PuWCNAOhDnY" --region us-west-2 --query SecretString --output text)
HOST=$(echo $SECRET_JSON | jq -r '.host')
USERNAME=$(echo $SECRET_JSON | jq -r '.username')
PASSWORD=$(echo $SECRET_JSON | jq -r '.password')
DATABASE=$(echo $SECRET_JSON | jq -r '.dbname')

echo "RDS Host: $HOST"

# Download CSV from S3
aws s3 cp s3://creditunion-546549546983-us-west-2-collect/CreditUnionData/core_banking_members.csv /tmp/core_banking_members.csv --region us-west-2

# Install mysql client if not available
sudo apt update && sudo apt install -y mysql-client

# Create SQL script to load data
cat > /tmp/load_data.sql << 'SQLEOF'
CREATE TABLE IF NOT EXISTS core_banking_members (
    member_number VARCHAR(20) PRIMARY KEY,
    ssn VARCHAR(11),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dob DATE,
    address VARCHAR(200),
    city VARCHAR(50),
    state VARCHAR(2),
    zip VARCHAR(10),
    phone VARCHAR(20),
    join_date DATE,
    checking_balance DECIMAL(10,2),
    savings_balance DECIMAL(10,2)
);

DELETE FROM core_banking_members;

LOAD DATA LOCAL INFILE '/tmp/core_banking_members.csv'
INTO TABLE core_banking_members
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

SELECT COUNT(*) as 'Records Loaded' FROM core_banking_members;
SQLEOF

# Execute SQL
mysql -h $HOST -u $USERNAME -p$PASSWORD $DATABASE --local-infile=1 < /tmp/load_data.sql

echo "Data loading complete!"
