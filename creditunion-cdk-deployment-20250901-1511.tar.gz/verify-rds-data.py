#!/usr/bin/env python3
import json
import boto3
import pymysql

def main():
    print("Verifying RDS data load...")
    
    # Get RDS credentials from Secrets Manager
    secrets_client = boto3.client('secretsmanager', region_name='us-west-2')
    secret_response = secrets_client.get_secret_value(
        SecretId='DatabaseSecret86DBB7B3-7PuWCNAOhDnY'
    )
    
    secret = json.loads(secret_response['SecretString'])
    print(f"Connecting to RDS: {secret['host']}")
    
    # Connect to MySQL
    connection = pymysql.connect(
        host=secret['host'],
        user=secret['username'],
        password=secret['password'],
        database=secret['dbname'],
        port=secret['port']
    )
    
    try:
        with connection.cursor() as cursor:
            # Check if table exists
            cursor.execute("SHOW TABLES LIKE 'core_banking_members'")
            table_exists = cursor.fetchone()
            
            if table_exists:
                print("✅ Table 'core_banking_members' exists")
                
                # Get record count
                cursor.execute("SELECT COUNT(*) FROM core_banking_members")
                count = cursor.fetchone()[0]
                print(f"✅ Total records: {count}")
                
                # Get sample records
                cursor.execute("SELECT member_number, first_name, last_name, checking_balance, savings_balance FROM core_banking_members LIMIT 5")
                records = cursor.fetchall()
                
                print("\n📋 Sample records:")
                print("Member#    | Name              | Checking  | Savings")
                print("-" * 55)
                for record in records:
                    print(f"{record[0]:<10} | {record[1]} {record[2]:<10} | ${record[3]:<8} | ${record[4]}")
                
                # Verify data integrity
                cursor.execute("SELECT COUNT(*) FROM core_banking_members WHERE member_number IS NOT NULL AND first_name IS NOT NULL")
                valid_records = cursor.fetchone()[0]
                print(f"\n✅ Valid records (non-null key fields): {valid_records}")
                
                if count > 0:
                    print(f"\n🎉 SUCCESS: RDS contains {count} core banking member records!")
                else:
                    print("\n❌ WARNING: Table exists but contains no data")
            else:
                print("❌ ERROR: Table 'core_banking_members' does not exist")
                
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        return False
    finally:
        connection.close()
    
    return True

if __name__ == "__main__":
    main()
