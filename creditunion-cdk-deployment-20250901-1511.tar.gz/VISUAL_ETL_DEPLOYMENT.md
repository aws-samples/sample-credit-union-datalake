# Visual ETL Deployment Guide

This guide explains how to deploy Visual ETL jobs with CodeGenConfigurationNodes using the AWS Glue Resource Sync approach.

## Solution Overview

The Visual ETL deployment uses a hybrid approach:
1. **CDK Infrastructure**: Deploys core infrastructure (roles, connections, databases)
2. **Visual ETL Construct**: Custom CDK construct that deploys Visual ETL jobs with CodeGenConfigurationNodes
3. **AWS CLI Integration**: Uses AWS SDK within Lambda to properly handle Visual ETL configurations

## Files Created

- `lib/visual-etl-construct.ts` - CDK construct for Visual ETL deployment
- `scripts/process-visual-etl.js` - Utility to process Visual ETL configurations
- `scripts/deploy-visual-etl.sh` - Shell script for manual deployment
- `lib/visual-etl-jobs.ts` - Generated CDK code (reference)

## Deployment Steps

### 1. Deploy Infrastructure First
```bash
cdk deploy CreditUnionInfrastructureStack --region us-west-2
```

### 2. Deploy Data Stack
```bash
cdk deploy CreditUnionDataStack --region us-west-2
```

### 3. Deploy ETL Stack (includes Visual ETL)
```bash
cdk deploy CreditUnionETLStack --region us-west-2
```

The Visual ETL construct will automatically:
- Deploy Visual ETL jobs with proper CodeGenConfigurationNodes
- Update S3 paths for the new region
- Configure connections and roles correctly

### 4. Manual Deployment (Alternative)
If you prefer manual control:
```bash
./scripts/deploy-visual-etl.sh \
  --role-arn arn:aws:iam::ACCOUNT:role/ROLE_NAME \
  --connection-name creditunion-mysql-connection \
  --region us-west-2
```

## Visual ETL Jobs Included

1. **creditunion-visual-mysql-etl**
   - Source: MySQL RDS (core_banking_members)
   - Transform: Adds dynamic partitioning (year/month/day/hour)
   - Destination: S3 Parquet with Glue Catalog

## Configuration Files

Visual ETL configurations are stored in `configs/`:
- `mysql-etl-config.json` - MySQL to S3 ETL with partitioning
- `csv-etl-config.json` - CSV processing ETL
- `xml-etl-config.json` - XML processing ETL
- `member360-etl-config.json` - Member 360 view ETL

## Key Features

- **CodeGenConfigurationNodes**: Preserves Visual ETL logic
- **Dynamic Partitioning**: Automatic year/month/day/hour partitioning
- **Custom Transforms**: Python code for data transformation
- **Schema Evolution**: Automatic catalog updates
- **Data Quality**: Built-in data quality checks

## Verification

After deployment, verify Visual ETL jobs:
```bash
aws glue get-job --job-name creditunion-visual-mysql-etl --region us-west-2
```

The job should include `CodeGenConfigurationNodes` with the complete Visual ETL definition.
