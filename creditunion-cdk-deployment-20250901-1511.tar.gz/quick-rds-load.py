#!/usr/bin/env python3
import boto3
import pymysql
import csv
import json

# Get RDS credentials
secrets = boto3.client('secretsmanager', region_name='us-west-2')
secret = json.loads(secrets.get_secret_value(SecretId='DatabaseSecret86DBB7B3-7PuWCNAOhDnY')['SecretString'])

# Download CSV from S3
s3 = boto3.client('s3', region_name='us-west-2')
s3.download_file('creditunion-546549546983-us-west-2-collect', 'CreditUnionData/core_banking_members.csv', '/tmp/core_banking_members.csv')

# Connect to MySQL
conn = pymysql.connect(
    host=secret['host'],
    user=secret['username'], 
    password=secret['password'],
    database=secret['dbname'],
    port=secret['port']
)

with conn.cursor() as cursor:
    # Create table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS core_banking_members (
            member_number VARCHAR(20) PRIMARY KEY,
            ssn VARCHAR(11), first_name VARCHAR(50), last_name VARCHAR(50),
            dob DATE, address VARCHAR(200), city VARCHAR(50), state VARCHAR(2),
            zip VARCHAR(10), phone VARCHAR(20), join_date DATE,
            checking_balance DECIMAL(10,2), savings_balance DECIMAL(10,2)
        )
    """)
    
    # Clear and load data
    cursor.execute("DELETE FROM core_banking_members")
    
    with open('/tmp/core_banking_members.csv', 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cursor.execute("""
                INSERT INTO core_banking_members VALUES 
                (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """, tuple(row.values()))
    
    conn.commit()
    cursor.execute("SELECT COUNT(*) FROM core_banking_members")
    print(f"Loaded {cursor.fetchone()[0]} records")

conn.close()
