#!/bin/bash

echo "Loading RDS MySQL data from CloudShell..."

# Get your current IP
MY_IP=$(curl -s https://checkip.amazonaws.com)/32
echo "Your IP: $MY_IP"

# Temporarily add CloudShell access to RDS security group
echo "Adding temporary access to RDS..."
aws ec2 authorize-security-group-ingress \
  --group-id sg-00953749bc2402067 \
  --protocol tcp \
  --port 3306 \
  --cidr $MY_IP \
  --region us-west-2

# Get RDS credentials
SECRET_JSON=$(aws secretsmanager get-secret-value --secret-id "DatabaseSecret86DBB7B3-7PuWCNAOhDnY" --region us-west-2 --query SecretString --output text)
HOST=$(echo $SECRET_JSON | jq -r '.host')
USERNAME=$(echo $SECRET_JSON | jq -r '.username')
PASSWORD=$(echo $SECRET_JSON | jq -r '.password')
DATABASE=$(echo $SECRET_JSON | jq -r '.dbname')

echo "RDS Host: $HOST"

# Download CSV from S3
aws s3 cp s3://creditunion-546549546983-us-west-2-collect/CreditUnionData/core_banking_members.csv /tmp/core_banking_members.csv --region us-west-2

# Install mysql client
sudo yum install -y mysql

# Create and run SQL
mysql -h $HOST -u $USERNAME -p$PASSWORD $DATABASE << 'SQLEOF'
CREATE TABLE IF NOT EXISTS core_banking_members (
    member_number VARCHAR(20) PRIMARY KEY,
    ssn VARCHAR(11),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dob DATE,
    address VARCHAR(200),
    city VARCHAR(50),
    state VARCHAR(2),
    zip VARCHAR(10),
    phone VARCHAR(20),
    join_date DATE,
    checking_balance DECIMAL(10,2),
    savings_balance DECIMAL(10,2)
);

DELETE FROM core_banking_members;

LOAD DATA LOCAL INFILE '/tmp/core_banking_members.csv'
INTO TABLE core_banking_members
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

SELECT COUNT(*) as 'Records Loaded' FROM core_banking_members;
SQLEOF

# Remove temporary access
echo "Removing temporary access..."
aws ec2 revoke-security-group-ingress \
  --group-id sg-00953749bc2402067 \
  --protocol tcp \
  --port 3306 \
  --cidr $MY_IP \
  --region us-west-2

echo "Data loading complete!"
