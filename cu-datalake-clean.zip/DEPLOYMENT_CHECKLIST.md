# Credit Union Analytics CDK - Deployment Checklist

**Quick reference for deploying and testing the complete platform**

## ✅ **Pre-Deployment Checklist**

- [ ] AWS CLI configured with admin permissions
- [ ] Node.js v18+ installed
- [ ] AWS CDK installed globally (`npm install -g aws-cdk`)
- [ ] Docker running
- [ ] In correct directory: the cloned repository root

## 🚀 **Deployment Steps**

### Step 1: Install & Bootstrap
```bash
npm install
cdk bootstrap  # First time only
```

### Step 2: Deploy Stacks (15-20 minutes total)
```bash
# Option A: Deploy all at once
npm run deploy

# Option B: Deploy individually (recommended)
cdk deploy CreditUnionInfrastructureStack  # ~8 minutes
cdk deploy CreditUnionDataStack            # ~3 minutes  
cdk deploy CreditUnionETLStack             # ~5 minutes
```

### Step 3: Post-Deployment Setup
```bash
# Start XML crawlers (required for XML ETL jobs)
aws glue start-crawler --name creditunion-creditcards-xml-crawler --region us-east-2
aws glue start-crawler --name creditunion-crm-xml-crawler --region us-east-2

# Wait 2-3 minutes for crawlers to complete
```

## 🧪 **Testing Checklist**

### Test 1: Individual Jobs (5-10 minutes each)
```bash
# MySQL ETL (should work immediately)
aws glue start-job-run --job-name creditunion-visual-mysql-etl --region us-east-2

# CSV ETL (should work immediately)  
aws glue start-job-run --job-name creditunion_CSV_collect_to_cleanse_visual --region us-east-2

# XML ETL (requires crawlers to complete first)
aws glue start-job-run --job-name creditunion-xml-collect-to-cleanse-visual --region us-east-2

# Member 360 ETL (run after cleanse jobs complete)
aws glue start-job-run --job-name creditunion-member-360-visual-etl --region us-east-2
```

### Test 2: Complete Pipeline Test
```bash
# Get your account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Run comprehensive test
aws stepfunctions start-execution \
  --state-machine-arn "arn:aws:states:us-east-2:${ACCOUNT_ID}:stateMachine:creditunion-etl-state-machine" \
  --input '{"execution_mode": "test_all", "p_year": "2025", "p_month": "08", "p_day": "28"}' \
  --region us-east-2
```

### Test 3: Data Verification
```bash
# Check member_profile table
aws athena start-query-execution \
  --query-string "SELECT COUNT(*), MAX(runid) FROM creditunion_consume.member_profile" \
  --result-configuration OutputLocation=s3://aws-athena-query-results-${ACCOUNT_ID}-us-east-2/ \
  --work-group primary \
  --region us-east-2
```

## ✅ **Success Criteria**

- [ ] **Infrastructure Stack**: Deployed successfully (~8 min)
- [ ] **Data Stack**: Deployed successfully (~3 min)
- [ ] **ETL Stack**: Deployed successfully (~5 min)
- [ ] **XML Crawlers**: Completed successfully (~2-3 min)
- [ ] **MySQL ETL Job**: Runs successfully (~5-10 min)
- [ ] **CSV ETL Job**: Runs successfully (~3-5 min)
- [ ] **XML ETL Job**: Runs successfully (~3-5 min)
- [ ] **Member 360 ETL Job**: Runs successfully (~5-10 min)
- [ ] **Step Functions Test**: All jobs pass (~20-25 min total)
- [ ] **Data Verification**: ~2,000 member profiles with RunID field

## 🚨 **Common Issues & Quick Fixes**

**Issue**: Lambda timeout during RDS data loading  
**Fix**: Check CloudWatch logs, may need to increase timeout

**Issue**: Glue job fails with connection error  
**Fix**: Verify security groups allow MySQL traffic (port 3306)

**Issue**: XML ETL job fails  
**Fix**: Ensure XML crawlers completed successfully first

**Issue**: Step Functions execution fails  
**Fix**: Check individual job status, run jobs individually first

## 📊 **Expected Results**

**After successful deployment:**
- **RDS MySQL**: ~2,000 core banking member records
- **S3 Collect**: 4 sample files (XML + CSV)
- **S3 Cleanse**: Processed Parquet files from all sources  
- **S3 Consume**: ~2,000 Member 360 profiles with RunID
- **Total Time**: ~45-60 minutes for complete deployment and testing

## 🔄 **Quick Commands for Future Sessions**

```bash
# Check deployment status
cdk list

# Re-run pipeline test
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
aws stepfunctions start-execution \
  --state-machine-arn "arn:aws:states:us-east-2:${ACCOUNT_ID}:stateMachine:creditunion-etl-state-machine" \
  --input '{"execution_mode": "test_all"}' \
  --region us-east-2

# Quick data check
aws athena start-query-execution \
  --query-string "SELECT COUNT(*) FROM creditunion_consume.member_profile" \
  --result-configuration OutputLocation=s3://aws-athena-query-results-${ACCOUNT_ID}-us-east-2/ \
  --work-group primary \
  --region us-east-2

# Cleanup everything
npm run destroy
```

---

**Total deployment time: ~20 minutes**  
**Total testing time: ~25-40 minutes**  
**Complete end-to-end: ~45-60 minutes**
